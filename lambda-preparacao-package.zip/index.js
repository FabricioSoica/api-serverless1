const AWS = require("aws-sdk");

// Configuração AWS usando credenciais do .env (AWS Academy)
AWS.config.update({
  region: process.env.APP_REGION || "us-east-1",
  accessKeyId: process.env.APP_ACCESS_KEY_ID,
  secretAccessKey: process.env.APP_SECRET_ACCESS_KEY,
  sessionToken: process.env.APP_SESSION_TOKEN
});

const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  console.log("Evento API Gateway recebido:", JSON.stringify(event, null, 2));

  try {
    // Extrai o idPedido do body (pode vir do API Gateway)
    let idPedido;
    
    if (event.body) {
      const body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
      idPedido = body.idPedido;
    } else if (event.idPedido) {
      idPedido = event.idPedido;
    }

    if (!idPedido) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'idPedido é obrigatório' })
      };
    }

    console.log(`Atualizando pedido ${idPedido} para PREPARACAO`);

    // Atualiza o status no DynamoDB
    await dynamo.update({
      TableName: "pedidos",
      Key: { idPedido },
      UpdateExpression: "SET #s = :s",
      ExpressionAttributeNames: { "#s": "status" },
      ExpressionAttributeValues: {
        ":s": "PREPARACAO"
      }
    }).promise();

    console.log(`Pedido ${idPedido} atualizado para PREPARACAO com sucesso`);

    // O DynamoDB Stream vai acionar a lambda-notificacao automaticamente
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        message: 'Status atualizado para PREPARACAO',
        idPedido
      })
    };
  } catch (err) {
    console.error("Erro no lambda-preparacao:", err);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({ error: 'Erro ao atualizar status', details: err.message })
    };
  }
};

